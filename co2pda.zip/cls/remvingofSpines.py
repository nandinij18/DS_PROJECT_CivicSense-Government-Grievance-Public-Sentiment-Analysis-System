import matplotlib.pyplot as plt
import seaborn as sns
# Load dataset
data = sns.load_dataset("iris")
# Create line plot
sns.lineplot(x="sepal_length", y="sepal_width", data=data)
sns.despine(left='True')
# Display plot
plt.show()
