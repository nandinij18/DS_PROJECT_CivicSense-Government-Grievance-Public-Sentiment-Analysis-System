import matplotlib.pyplot as plt
values=[5,6,3,7,2]
names=["A","B","C","D","E"]
plt.bar(names,values,color="green")
plt.title('Bar Graph')
plt.xlabel('Names')
plt.ylabel('Values')
plt.show()