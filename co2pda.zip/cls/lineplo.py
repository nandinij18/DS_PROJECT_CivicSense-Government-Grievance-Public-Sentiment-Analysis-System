import matplotlib.pyplot as plt
import seaborn as sns
# Set the style
sns.set_style("dark")
# Load dataset
df = sns.load_dataset("iris")
# Create line plot
sns.lineplot(x="sepal_length", y="sepal_width", data=df)
# Display plot
plt.show()
