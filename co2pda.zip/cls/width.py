
import matplotlib.pyplot as plt
values = [5, 6, 3, 7, 2]
names = ["A", "B", "C", "D", "E"]
C2 = ['b', 'g', 'r', 'y', 'm']
plt.bar(names, values, width=0.5, color=C2)
plt.show()