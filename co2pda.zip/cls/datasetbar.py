import matplotlib.pyplot as plt
import pandas as pd
df=pd.read_csv("temporal (1).csv")
plt.bar(df['deep learning'],df['machine learning'],color='red')
plt.xlabel('Deep Learning')
plt.ylabel('Machine Learning')
plt.title('bar graph')
plt.show()

