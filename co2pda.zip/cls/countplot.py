import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
df = pd.read_csv("temporal (1).csv")
sns.countplot(x='Pclass',hue='Sex',data=df,color='green')
plt.show()