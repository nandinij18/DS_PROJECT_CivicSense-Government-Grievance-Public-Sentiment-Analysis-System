import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
df = pd.read_csv("temporal (1).csv")
sns.lineplot(x="data Science", y="machine learning", data=df)
plt.show()


