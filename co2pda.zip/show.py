import matplotlib.pyplot as plt
x=[1,2,3,4,5]
y=[2,4,6,3,10]
plt.plot(x,y)
plt.show()

plt.title("Line Graph")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.plot(x,y)
plt.show()