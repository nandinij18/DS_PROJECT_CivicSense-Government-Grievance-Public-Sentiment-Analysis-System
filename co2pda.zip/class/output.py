
import seaborn as sns
import pandas as pd
import numpy as np
df=pd.read_csv('train.csv')
df 
Q1=np.percentile(df['Weekly_Sales'],25,interpolation='midpoint')
Q3=np.percentile(df['Weekly_Sales'],75,interpolation='midpoint')
IQR=Q3-Q1
