import app
from app import dcc, html

app = app.Dash(__name__)

app.layout = html.Div([
    html.H1("Dash Tutorial"),

    dcc.Graph(
        id="example",
        figure={
            "data": [
                {
                    "x": [1,2, 3],
                    "y": [4, 1, 2],
                    "type": "bar",
                    "name": "SF"
                },
                {
                    "x": [1, 2, 3],
                    "y": [2, 4, 5],
                    "type": "bar",
                    "name": "NYC"
                }
            ],
            "layout": {
                "title": "Basic Dashboard"
            }
        }
    )
])

app.run(debug=True)