import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
data = [12, 15, 20, 20, 22, 23, 25, 25, 30, 35, 40]
plt.hist(data, bins=5, color='red', edgecolor='green')
plt.title("Histogram")
plt.xlabel("Values")
plt.ylabel("Frequency")
plt.show()

