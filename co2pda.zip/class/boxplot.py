import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
df=pd.read_csv('train.csv')
import numpy as np
plt.boxplot(df['Weekly_Sales'])
plt.show()
