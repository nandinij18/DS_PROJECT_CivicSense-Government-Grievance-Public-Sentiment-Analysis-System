import pandas as pd

df=pd.DataFrame({
    'ID':[1,2,3,4,5,1,2,3],
    'Name':['Alice','Bob','Charlie','David','Eve','Alice','Bob','Charlie'],
    'Age':[25,30,35,40,45,25,30,35]
})
print("Original Dat:\n",df)

#REMOVE exact duplicates
df_exact_duplicates = df.drop_duplicates()
print("\nAfter exact Match Removal:\n",df_exact_duplicates)