#FORWARD FILL
import pandas as pd
import numpy as np
df=pd.DataFrame({
    'Age':[25,30,np.nan,40,38],
    'Department': ['HR','Finance','Finance',np.nan,'IT']
})

#display original dataset
df_ffill=df.copy()
df_ffill.ffill(inplace=True)
print(df_ffill)


#BACKFORD FILL
import pandas as pd
import numpy as np
df=pd.DataFrame({
    'Age':[25,30,np.nan,40,38],
    'Department': ['HR','Finance','Finance',np.nan,'IT']
})

#display original dataset
df_bfill=df.copy()
df_bfill.bfill(inplace=True)
print(df_bfill)


