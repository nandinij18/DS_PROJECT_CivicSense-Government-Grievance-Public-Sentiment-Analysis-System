import pandas as pd
import numpy as np
df = pd.DataFrame({
    'Id': [1,2,2,3,4,4],
    'Name': ['Nandini', 'Chetna', 'Chetna', 'deepika', 'Hasika','Hasika'],
    'Age': [25,30,40,35,40,40]
})
#print original dataset
print(df)
#remove duplicates on id
df_subset_id=df.drop_duplicates(subset=['Id'])
print(df_subset_id)
#remove duplicaes on name
df_subset_name=df.drop_duplicates(subset=['Name'])
print(df_subset_name)