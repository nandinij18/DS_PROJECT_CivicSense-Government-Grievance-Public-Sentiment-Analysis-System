import pandas as pd
df=pd.read_csv('Iris (1).csv')
print(df)


#TOP ROWS
print(df.head(10))

#deatils of the dataset
print(df.info())

#NO OF ROWS AND COLUMNS
print(df.shape)


import pandas as pd

data3 = {
    'row1': [3, 2, 1, 0],
    'row2': ['a', 'b', 'c', 'd']
}

df = pd.DataFrame.from_dict(
    data3,
    orient='index',
    columns=['A', 'B', 'C', 'D']
)

print(df)

