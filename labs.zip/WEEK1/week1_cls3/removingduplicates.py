import pandas as pd
df=pd.read_csv('Iris (1).csv')
print(df.shape)


#to duplicste all rows
dup_df = pd.concat([df, df], ignore_index=True)
print(dup_df.shape)


#to remove all duplicates
dup_df.drop_duplicates(inplace=True)
print(dup_df.shape)

#describes the data
print(df.describe())



