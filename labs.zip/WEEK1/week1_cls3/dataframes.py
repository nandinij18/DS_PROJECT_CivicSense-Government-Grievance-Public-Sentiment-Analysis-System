import pandas as pd
data={'apples':[3,1,8,0],'oranges':[0,3,6,4]}
df=pd.DataFrame(data)
print(df)


import pandas as pd
data={'apples':[3,1,8,0],'oranges':[0,3,6,4]}
index=['Tom','Dick','Harry','Sally']
df=pd.DataFrame(data,index=index)
print(df)


#TO LOCATE INDEX
import pandas as pd
data={'apples':[3,1,8,0],'oranges':[0,3,6,4]}
index=['Tom','Dick','Harry','Sally']
print(df.loc['Tom'])
