#DATA FROM JSON
import pandas as pd
df=pd.read_json('sample1.json')
print(df)

