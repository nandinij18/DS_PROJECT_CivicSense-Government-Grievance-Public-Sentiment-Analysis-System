import numpy as np

#intializing zeroes and ones
n=np.array([1,3,5,7])
m=np.array(np.zeros((3,4)))
print(m)


