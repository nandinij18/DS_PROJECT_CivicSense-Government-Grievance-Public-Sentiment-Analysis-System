import numpy as np

#SHAPE OF AN ARRAY
n=np.array([1,2,5,6])
print(n.shape)

#RESHAPING OF AN ARRAY
m=np.array([1,2,3,4,5,6])
print(m.reshape(2,3))
