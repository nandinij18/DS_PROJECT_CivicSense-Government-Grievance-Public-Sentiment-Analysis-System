import numpy as np


#sum()
n=np.array([12,3,4,5])
print(np.sum(n))

#subtract()
print(np.subtract(5,3))

#multiply()
print(np.multiply(5,3))

#divide()
print(np.divide(1,3))
