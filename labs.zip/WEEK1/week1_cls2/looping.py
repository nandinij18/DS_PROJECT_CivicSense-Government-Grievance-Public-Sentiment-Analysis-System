import numpy as np

#looping through an array
arr=np.array([1,2,3,4])
for i in arr:
    print(i)