import numpy as np
n1=np.array([1,2,5,7])
n2=np.array([1,9,0,7])
n3=np.concatenate((n1,n2))
print(n3)