import numpy as np

p=np.array([12,45,89,90])
print(p[1])


p=np.array([[12,45,89,90],[23,56,78,99]])
print(p[1,2])


#NEGITIVE INDEXING
P=np.array([1,2,3])
print(P[-1])

    



