import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris

# Load Iris dataset
iris = load_iris()

# Create DataFrame
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['species'] = iris.target


# 3.multivariate visualizations
#heatmap(correlation matrix)
plt.figure(figsize=(8,6))
sns.heatmap(df.iloc[:,:4].corr(), annot=True, cmap="coolwarm")
plt.title("Heatmap of Feature Correlations")
plt.show()
#Bubble Chart (scatterplot with size = petal length)
plt.figure(figsize=(6,4))
plt.scatter(df['sepal length (cm)'], df['sepal width (cm)'], s=df['petal length (cm)']*20, alpha=0.5, c=df['species'])
plt.title("Bubble Chart: Sepal vs Petal (size = petal length)")
plt.xlabel("Sepal Length (cm)")
plt.ylabel("Sepal Width (cm)")
plt.show()
#pair plot (relationships among all features)
sns.pairplot(df.iloc[:,:4])
plt.suptitle("Pair Plot of Iris Features", y=1.02)
plt.show()