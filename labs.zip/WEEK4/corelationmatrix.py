import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
corr = df.corr(numeric_only=True)
print(corr)
sns.heatmnap(corr, annot=True, cmap='coolwarm')




