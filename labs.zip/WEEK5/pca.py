import pandas as pd
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

#load dataset
tips=sns.load_dataset("tips")

#Select numeric colums
numeric_cols=tips.select_dtypes(include=['float64', 'int64']).columns

#step1: Standardization(important for PCA)
scaler=StandardScaler()
scaled_data=scaler.fit_transform(tips[numeric_cols])

#step2:apply PCA
pca=PCA(n_components=2)
pca_result=pca.fit_transform(scaled_data)


#step3:Create a DataFrame with PCA results
pca_df=pd.DataFrame(data=pca_result, columns=['PC1', 'PC2'])

print("Explained Variance:",pca.explained_variance_ratio_)
print("\nPCA Result (first 5 rows): ")
print(pca_df.head())


