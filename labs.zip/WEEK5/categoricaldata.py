import pandas as pd
df = pd.DataFrame({'Color': ['Red', 'Blue', 'Green', 'Red', 'Blue']})
on_hot = pd.get_dummies(df, columns=['Color'])
print("\nOne Hot Encoding:")
print(on_hot)