
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
# Load dataset
df = pd.read_csv("Iris (1) (1).csv")
# Select only numeric columns
X = df.select_dtypes(include=["number"])
# Standardize the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
# Apply PCA
pca = PCA(n_components=2)
principal_components = pca.fit_transform(X_scaled)
# Create a DataFrame for PCA results
pca_df = pd.DataFrame(
    principal_components,
    columns=["PC1", "PC2"]
)
# Display PCA data
print(pca_df.head())
# Plot PCA projection
plt.scatter(pca_df["PC1"], pca_df["PC2"], alpha=0.7)
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA Projection of Iris Dataset")
plt.show()